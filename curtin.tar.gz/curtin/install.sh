
#!/bin/bash
apt-get install	 -y pmount mp3info bc mp3blaster espeak alsa-oss mpgtx screen alsa-utils
touch /media/book.dat
pwd=$(pwd)
cp $pwd/raspi-config.sh /etc/profile.d/raspi-config.sh
cp $pwd/all.x /media
cp $pwd/all.sh /media
cp $pwd/page /media
cp $pwd/headi /media
cp $pwd/head /media
cp $pwd/mp3blast /media
