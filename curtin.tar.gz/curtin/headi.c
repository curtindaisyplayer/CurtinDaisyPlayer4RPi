
   
    #include <iostream>
    #include <fstream>
   
     using namespace std;
int main()
{
	int	length=0;
	char * buffer;   	
	string headi,fil,inp,smil,smill, map;
         fil="headi.txt";
  	 ifstream is;
       is.open (fil.c_str(), ifstream::in );
       is.seekg (0, ios::end);
       length = is.tellg();
       is.seekg (0, ios::beg);
       buffer = new char [length];
       is.read (buffer,length);
       is.close();
       inp=buffer;
map=inp;        
char  ch='"';
string clas;
string  sh;
sh=ch;
clas="class="+sh+"h";
//inp=inp.substr(inp.find("<navlabel"));         

while(inp.find(clas)!=-1){
//          cout<<inp<<endl;

 headi=inp.substr(inp.find(clas)+8,1);
 inp=inp.substr(inp.find(clas)+headi.length()+15);         
 smil=inp.substr(inp.find("src=")+5,inp.find(".mp3")-inp.find("src=")-5)+".mp3";
// inp=inp.substr(inp.find("</navlabel"));         
          cout<<smil+"   "+headi<<endl;

                     
}
	return 0;
}
