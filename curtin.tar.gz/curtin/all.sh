#!/bin/bash
####################################################


#key combination playing time( 0=quit 1=rew 7=ff 2,4,6,8 =navigate 5=pause,resume i=inforation -=vol- +=vol+)
#oo=select  audio annotating o*=select text annotating oo5=remove audio o*5=remove text
#..=record  audio annotating .*=rercord text annotating       	
#gawk '{print NF}' return no of column
#######################################################
_key()


{
  local kp
  ESC=$'\e'
  _KEY=
  read -d '' -sn1 _KEY
  case $_KEY in
    "$ESC")
        while read -d '' -sn1 -t1 kp
        do
          _KEY=$_KEY$kp
          case $kp in
            [a-zA-NP-Z~]) break;;
          esac
        done
    ;;
  esac
  printf -v "${1:-_KEY}" "%s" "$_KEY"

}
####################################################
_pre(){
tit=$(echo $title|sed 's/ //g')
j=$(cat /media/book.dat|egrep -ic $tit )
if [[ $j  -gt 0 ]]
then  
file=($( awk -F, '$1 ~ /'$tit'/{print $2}' /media/book.dat))
elapsetime=($( awk -F, '$1 ~ /'$tit'/{print $3}' /media/book.dat))

jj=0
echo ${elapsetime[@]}
for i in `seq 0 $(($j-1))`;
do	
da=${elapsetime[$i]}
da=$(($da-1))
t=$(($da-10))
in=$(mp3info -p %S $path"/"$file)
if [ $da -gt 11 ] && [ $da -lt  $in ]
then
t=$(($da-10))
ss=$( date --utc --date="@$da" +%H:%M:%S)
ee=$( date --utc --date="@$t" +%H:%M:%S)
sss=$(date +%s)
mpgsplit $path"/"${file[$jj]}  "["$ee"-"$ss"]" -o  "/media/"${tit:0:10}$jj$sss".mp3"
jj=$(($jj+1))

fi
done

if [ $jj -gt 0 ]
then
i=0	
while  [  $i -ge 0 ] || [ $i -le $jj ] ;
do

if [ $i  -eq $jj ] 
 then
  i=0
fi
 screen -d -m -S  mp3blaster  aoss  mp3blaster  "/media/"${tit:0:10}$i$sss".mp3" -c mp3blast 


_key x
case $x in
 
  ?) key=$x ;;
  *) key=??? ;;
esac
		

if [ $key -eq  7 ]
then
 i=$(( $i + 1 ))

fi
if [ $key -eq  1 ]
then
 i=$(( $i - 1 ))

 if [ $i  -lt 0 ]	
 then
  i=$(($jj+$i))
fi
fi
if [ $key -eq 0 ] 
then

  break

fi
 done

fil=${file[$i]}
elapse=${elapsetime[$i]}   
	
else
j=$(($j-1))
fil=${file[$j]}
elapse=0
fi



else 
fil=${smil[0]}
elapse=0

fi
orig=$fil
dateb=$(date  +"%s")
}
########################################
_speech_rate(){
wc -c test.txt
wc -w test.txt
espeak -f test.txt -w test.wav
lame -V3 test.wav test.mp3
mp3info -p %S test.mp3
}
_info()
{

for i in `seq 0 $indexn`;
do 
pass=$(( $(mp3info -p %S $path"/"${smil[$i]})+$pass))
done
espeak  "$title"
espeak "totaltime is "${Time[0]}"hours  and"${Time[1]}"minutes and"${Time[2]}"seconds"
#pass=$(($pass+$elapse+$diff))
pass=$(date +"%s")
pass=$(($pass-$dateb))
remain=$(($seconds-$pass))
pass=$( date --utc --date="@$pass" +%H:%M:%S)
espeak "elapsed time is "${pass:0:2}"hours  and"${pass:3:2}"minutes and"${pass:6:2}"seconds"
remain=$( date --utc --date="@$remain" +%H:%M:%S)
espeak "remained time is "${remain:0:2}"hours  and"${remain:3:2}"minutes and"${remain:6:2}"seconds"
echo $pass
echo $remain
echo $seconds
}
#################################################
_time_calculator(){
nodivider=$(echo  "$totaltime"|grep -o ":"|wc -l )

if [ $nodivider -eq 1 ]
then
 totaltime="00:"$totaltime
fi
SavedIFS="$IFS"
IFS=":."
Time=($totaltime)
if  [    ${Time[0]}  -eq     "09"  ]
then
Time[0]="10"
Time[1]="00"
fi
seconds=$((${Time[0]}*3600+${Time[1]}*60 + ${Time[2]})).${Time[3]}
IFS="$SavedIFS"
seconds=$(echo $seconds/1 | bc)
echo $totaltime
echo $seconds
}

#fseconds=$(echo "$Time" | awk -F':.'  '{ print $1*3600 + $2*60 + $3 }')
#############################################	

_mp3player(){
exit=0
orig=$fil	
freq=$(mp3info -p %Q $path"/"$fil)
info=$(mp3info -p %S $path"/"$fil)
duration=$info
info=$(($info-1))
info=$( date --utc --date="@$info" +%H:%M:%S)
elps=$( date --utc --date="@$elapse" +%H:%M:%S)
to=1
if [ $elapse -ne 0 ]
then 
 while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done

 mpgsplit  $path"/"$fil  "["$elps"-"$info"]" -o  $path"/"$to"z.mp3"
fil=$to"z.mp3"

fi
volume=50
speed=1.0
pause=0	 
tpause=0
diff=0
date1=$(date +"%s")
screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 

while [[ $duration  -gt $now ]]
do
pass=$(date +"%s")
pass=$(($pass -$dateb))
echo $pass

if  [[ $sleeptime  -gt  $pass  ]]
then 
now=$(date +"%s")
now=$(($now -$date1))
read -n1 -t1 y		
case "$y" in					
0) 
killall -v  mp3blaster
  exit=1
date2=$(date +"%s")
dad=$(($date2-$date1))
elapse=$(($elapse+$dad))
nol=$(cat /media/book.dat|wc -l) 
if [[ $nol -gt 1000 ]]
then 
 espeak "your current bookmark file is overload the  system is  going to make backup and generate new one ,please  wait  " 
mv /media/book.dat  /media/book.bak 
touch book.dat
fi 
echo  $tit","$orig","$elapse >> /media/book.dat
break;;


i)
pause=1
tpause=$(date +"%s")
pause_diff=$(($tpause-$date1))
killall 	 -v mp3blaster
_info
info=$(mp3info -p %S $path"/"$fil)
duration=$info
info=$(($info- 1))
pause_diff=$(($tpause-$date1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
done

mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o   $path"/"$to"z.mp3"
fil=$to"z.mp3"


date1=$(date +"%s")
screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 
pause=0;;
3)
   speed=$(echo $speed-0.1|bc);;
9)
	   speed=$(echo $speed+0.1|bc)  ;;
7)
info=$(mp3info -p %S $path"/"$fil)
duration=$info
tpause=$(date +"%s")
pause_diff=$(($tpause-$date1+10))
if [[ $pause_diff  -lt $duration ]]
then
killall -v mp3blaster
echo $duration
echo $pause_diff
info=$(($info- 1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done

mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o  $path"/"$to"z.mp3"
fil=$to"z.mp3"

date1=$(date +"%s")
screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 
else 
pause_diff=$(($tpause-$date1-10))
fi;;
1)
info=$(mp3info -p %S $path"/"$fil)
duration=$info
tpause=$(date +"%s")
pause_diff=$(($tpause-$date1-10))
if [[ $pause_diff  -gt 0 ]]
then
killall -v mp3blaster
info=$(($info- 1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done
mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o  $path"/"$to"z.mp3"
fil=$to"z.mp3"
date1=$(date +"%s")
screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 

echo i am her
else 
pause_diff=$(($tpause-$date1+10))
fi;;
		
-)
   volume=$(($volume-10))
#  amixer set Headset Playback Volume  $volume"%";;BB
  amixer set PCM Playback Volume  $volume"%";;
  
+)
 volume=$(($volume+10))
#     amixer set Headset Playback Volume  $volume"%";;
  
  amixer set PCM Playback Volume  $volume"%";;
  



2)
navigate=2
killall -v mp3blaster
break;;
4)
navigate=4
killall -v mp3blater
break;;
8)
navigate=8
killall -v mp3blaster
break;;
6)
navigate=6
killall -v mp3blaster
break;;


o)
killall -v  mp3blaster
  pause=1
  tpause=$(date +"%s")
  txt=($(ls   /media/${tit:0:5}*.txt))
  lin=($(ls   /media/${tit:0:5}*.mp3))
   not=${#txt[@]}
   noo=${#lin[@]}
 read -n1 -t1 v
 case "$v" in 
o)
if [ $noo -ne 0 ]
then 
i=0
while [ $i  -lt $noo ] || [ $i  -ge 0 ]
do
if [ $i  -eq $noo ] 
 then
  i=0
fi
echo ${lin[$i]}
_key w
case $w in
 
  ?) key=$w ;;
  *) key=??? ;;
esac
if [ $key -eq 7 ]
then
 i=$(( $i + 1 ))
 fi
if [ $key -eq 1 ]
then	
 i=$(( $i - 1 ))
 if [ $i  -lt 0 ] 	
then
  i=$(($noo+$i))
fi
fi
if [ $key -eq  0 ]
then
  break
fi
if [ $key -eq  5 ]
 then
 rm  ${lin[$i]}
  lin=($(ls   /media/${tit:0:5}*.mp3))
  noo=${#lin[@]}
 if [ $noo -eq  0 ]
 then     
 break 
fi 		

fi
 done    

screen -m -d -S mp3blaster screen -d -m -S  mp3blaster  aoss  mp3blaster ${lin[$i]} -c mp3blast 
else 
espeak "there is no audio note"
fi ;;


*)
if [ $not   -ne  0  ] 
then 
i=0
while [ $i  -lt $not ] || [ $i  -ge 0 ]
do
if [ $i  -eq $not ] 
 then
  i=0
fi
espeak ${txt[$i]}
_key w
case $w in
 
  ?) key=$w ;;
  *) key=??? ;;
esac
if [ $key -eq 7 ]
then
 i=$(( $i + 1 ))
 fi
if [ $key -eq 1 ]
then	
 i=$(( $i - 1 ))
 if [ $i  -lt 0 ] 	
 then
  i=$(($not+$i))
fi
fi
if [ $key -eq  0 ]
then
  break
fi

if [ $key -eq  5 ]
 then
 rm  ${txt[$i]}
   txt=($(ls   /media/${tit:0:5}*.txt))  
   not=${#txt[@]}
 if [ $not -eq  0 ]
 then     
 break 
fi 		
fi
 done    
espeak -f ${txt[$i]}
else 
espeak "there is no annotation note" 
fi ;;

esac
 	  	
info=$(mp3info -p %S $path"/"$fil)
duration=$info
info=$(($info- 1))
pause_diff=$(($tpause-$date1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done

mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o  $path"/"$to"z.mp3"
fil=$to"z.mp3"

date1=$(date +"%s")
 screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 
					pause=0;;
.)
killall -v mp3blaster
  pause=1
  tpause=$(date +"%s")
   read -n1 -t1 v
    case "$v" in 
 .)
			
    espeak "start recording"
     diffs=$(($diff-10))
     difs=$( date --utc --date="@$diffs"m +%H:%M:%S)
    mpgsplit $path"/"$fil "["$difs"-"$dife"]" -o $fil 
    r=`date +%M%d`".wav"
     arecord -t wav -c 2 -r $freq -f  S16_LE -v  $r  -d    10
    lame -V3        $r   ${tit:0:5}".mp3"
      mpgtx -j *.mp3 --force
   mp3val chunk.p3 -f -nb
    cp chunk.mp3 /media/${tit:0:5}`date +%M%d`".mp3"
    rm *.mp3
    espeak "end of  recording" 
;;
   *)
espeak  "start annotating"

read -n100   anno 

echo  $fil":"$diff":"$anno>>/media/${tit:0:5}`date +%M%d`".txt"
espeak "end of annotating"
;;
esac
info=$(mp3info -p %S $path"/"$fil)
duration=$info
info=$(($info- 1))
pause_diff=$(($tpause-$date1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done
 mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o   $path"/"$to"z.mp3"
fil=$to"z.mp3"
 screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 
					pause=0;;

					
5) 
read -n1 -t1 v  
case "$v" in 
    6)
navigate=3
killall -v  mp3blaster
break;;
     4)
navigate=5
killall 	-v  mp3blaster
break;;
*)
	 if [ $pause -eq 0 ]
then 
 killall -v mp3blaster
  pause=1
  tpause=$(date +"%s")

	
 else 

info=$(mp3info -p %S $path"/"$fil)
duration=$info
info=$(($info-1))
pause_diff=$(($tpause-$date1))
elapse=$(($elapse+$pause_diff))
pd=$( date --utc --date="@$pause_diff" +%H:%M:%S)
info=$( date --utc --date="@$info" +%H:%M:%S)
echo $info
echo $pd
while [ -f  $path"/"$to"z.mp3" ]
           do
               to=$(($to+1))
 done
mpgsplit  $path"/"$fil  "["$pd"-"$info"]" -o  $path"/"$to"z.mp3" 
fil=$to"z.mp3"

date1=$(date +"%s") screen -d -m -S  mp3blaster  aoss  mp3blaster $path"/"$fil  -c mp3blast 
					pause=0
fi
esac
;;

esac
else 
elapse=$(($elapse-5))
echo  $tit","$orig","$elapse >> /media/book.dat
stay=0
break

fi
done
killall -v mp3blaster

if  [[ $navigate -eq 0  ]]
 then   
 navigate=1
fi
zls=$(ls $path"/*z.mp3")

if [[  $zls  = ""  ]]
then
echo nothing 
else 
rm $path"/*z.mp3"
fi
}		
###########################################################################
_playorder(){ 
inx=5
#echo   $count
for i in `seq 1 $count`;
do
level1="$level""$i"
inx=$(awk -v a="$string" -v b="$level1" 'BEGIN{print index(a,b)+5}')
sub=$(awk -v a="$string" -v b="$inx"    'BEGIN{print substr(a,b)}')
nam=$(awk -v a="$sub" -v  b="src"    'BEGIN{print index(a,b)+5}')
ext=$(awk -v a="$sub" -v  b=".mp3"   'BEGIN{print index(a,b)}')
leng=$(($ext-$nam))
mp3[$i]=$(awk -v a="$sub" -v b="$nam"  -v c="$leng" 'BEGIN{print substr(a,b,c)}')".mp3"
done 
#echo ${mp3[@]}
}
###########################################################################
_paging(){
inx=5	
for i in `seq 1 $pageno`;
do 
#pagearea=${pagearea:$inx}
#inx=$(awk -v a="$pagearea" -v b="class=" 'BEGIN{print index(a,b)+8}')
#sub=$(awk -v a="$pagearea" -v b="$inx"    'BEGIN{print substr(a,b)}')
#nam=$(awk -v a="$sub" -v  b="src="    'BEGIN{print index(a,b)+5}')
#ext=$(awk -v a="$sub" -v  b=".mp3" 'BEGIN{print index(a,b)}')
#leng=$(($ext-$nam))
#clips=$(awk -v a="$sub" -v  b="clipBegin="    'BEGIN{print index(a,b)+11}')
#page[$i]=$(awk -v a="$sub" -v b="$nam"  -v c="$leng" 'BEGIN{print substr(a,b,c)}')".mp3"

#clip=$(awk -v a="$sub" -v b="$clips"  -v c=7 'BEGIN{print substr(a,b,c)}')

nodivider=$(echo  "${clip[$i]}"|grep -o ":"|wc -l )
if [ $nodivider -eq 1 ]
then
 clip="00:"${clip[$i]}
fi
clipsec[$i]=$(echo ${clip[$i]} | awk -F: '{ print ($1 * 3600) + ($2 * 60) + $3 }')



done
echo ${#clipsec[@]}
echo ${#page[@]}
}
####################################################################
_heading(){
echo $strin>headi.txt
./headi >heading.txt
head=($(cat heading.txt|awk '{print $2}'))
smil=($(cat heading.txt|awk '{print $1}')) 
#head=
# inx=5
classno=$(($classno-1))

for i in `seq 0 $classno`;
do 
#strin=${strin:$inx}
#inx=$(awk -v a="$strin" -v b="class=" 'BEGIN{print index(a,b)+8}')
#head[$i]=$(awk -v a="$strin" -v b="$inx"    'BEGIN{print substr(a,b,1)}')
#sub=$(awk -v a="$strin" -v b="$inx"    'BEGIN{print substr(a,b)}')
#nam=$(awk -v a="$sub" -v  b="src="    'BEGIN{print index(a,b)+5}')
#ext=$(awk -v a="$sub" -v  b=".mp3" 'BEGIN{print index(a,b)}')
#leng=$(($ext-$nam))
#smil[$i]=$(awk -v a="$sub" -v b="$nam"  -v c="$leng" 'BEGIN{print substr(a,b,c)}')".mp3"
code[$i]=0 

done
echo ${head[@]}
echo ${smil[@]}
}
#########################################
_coding(){
i=1
j=1
for i in `seq 1 $classno`;
   do
	if [[ ${head[$i]}  -eq 1 ]]
   then
  code[$i]=$j
   j=$(($j+1))   
   fi
	done
while  [ $depth -gt 1 ]
do

for i in `seq 1 $classno`;
   do

  if [[ ${head[$i]}  -eq $depth ]]
   then
   for k in `seq $i $classno`;
   do  
   if [ ${head[$k]}  -eq $(($depth-1)) ]
      then 
          break
     fi
     done 
     m=1
     for l in `seq $i $(($k-1))`;
      do
     if [ ${code[$l]} -eq 0 ]
       then
          code[$l]=$m
          m=$(($m+1))
        fi
       done
 fi
 done
depth=$(($depth-1))
done
echo "end of coding"
}
#############################################################

_navigating(){
	
pass=0
fix=1
pass=$(date +"%s")
pass=$(($pass-$dateb))

while  [[ $sleeptime  -gt $pass  ]]
do

if [[ $exit -eq 0  ]]
then 
fil=$orig

case $navigate in
0)

for i in `seq 0  $classno`;
do

if [ "${smil[$i]}" = "$fil" ];    
then

  headn=${head[$i]}
  coden=${code[$i]}
  indexn=$i
upn=$(($headn-1))
down=$(($headn+1))

    
break
fi
done
;;
6)


if [ $upn -gt 0  ]
then
for l in `seq  $(($indexn+1))  $classno`;
 do
    if [ ${head[$l]} -eq  $upn ]
     then   
       break
      fi
     done
if [ $l -le  $classno ]
then		
 for k in `seq  $(($indexn+1)) $l`;
   do 
    if [ ${head[$k]} -eq  $headn  ]

    then
        break
    fi
done
fi
else
for k in `seq  $(($indexn+1))  $classno`;
 do
   
 if [ ${head[$k]} -eq  $headn  ]
 
    then   

       break
      fi
     done
if [ $k -gt  $classno ]
then
 k=1
fi
fi


headn=${head[$indexn]}
upn=$(($headn-1))
down=$(($headn+1))
indexn=$k
elapse=0	
fil=${smil[$indexn]};;
	
#<------------
4)
if [ $upn -gt 0  ]
then
 

l=$(($indexn-1))
while [[ $l -ge 0  ]]
 do
    if [ ${head[$l]} -eq $upn ]
     then   
       break
      fi
            l=$(($l-1))
      done
if [ $l -ge   0  ] 
then
k=$(($indexn-1))
while [[ $k  -ge $l ]]
 do   
 if [ ${head[$k]} -eq $headn ]	
    then
   break
        fi
       k=$(($k-1))
done
fi
else

k=$(($indexn-1))
while [[ $k  -ge 0 ]]
 do   
 if [ ${head[$k]} -eq $headn ]	
    then
    break
  fi
     k=$(($k-1))
done

#k=$(($k+1))
#if [ $k -eq 0 ]
# then 
#  k=1
#Sfi
fi

indexn=$k
headn=${head[$indexn]}
upn=$(($headn-1))
down=$(($headn+1))
fil=${smil[$indexn]}
elapse=0;;
			
#<up---------

8)
if [ $upn -gt 0  ]
then
l=$(($indexn-1))	

while [[ $l -ge 0 ]]
 do
    if [ ${head[$l]} -eq $upn ]
     then   
       break
      fi
       l=$(($l-1))
done

if [ $l -lt 0  ]
then
 
l=$indexn
fi
else 
l=$indexn
fi
indexn=$l
headn=${head[$indexn]}
upn=$(($headn-1))
down=$(($headn+1))
fil=${smil[$indexn]}
elapse=0  ;;
#---->down
 2)
if [ $down  -le $depth ]
then 

for l in `seq  $(($indexn+1))  $classno`;
 do
    if  [ ${head[$l]} -eq $headn ]
     then   
 break
      fi
      done
if [ $l -gt $(($indexn+1))   ]
 then 
    k=$(($indexn+1))
else 
  k=$indexn
fi
else 
k=$indexn
fi
indexn=$k
headn=${head[$indexn]}
upn=$(($headn-1))
down=$(($headn+1))
fil=${smil[$indexn]}
elapse=0;;

1)

for i in `seq 0 $classno`;
do

if [ "${smil[$i]}" = "$fil" ];    
then
break
fi
done
o=$(($i+1))
fil=${smil[$o]}
headn=${head[$o]}
coden=${code[$o]}
elapse=0
indexn=$o;;
5)
i=$pageno 
while [ $i -ge 0 ]
do
if [[ "${page[$i]}" == "$fil" ]];    
    then
break
fi 
i=$(($i-1))
done
o=$(($i-1))
k=$o
echo $o
while [ $o -ge 0 ]
do  
if [ "${page[$o]}" = "$fil" ] && [ "${clipsec[$o]}" -lt  "$dif" ]
  then 
headn=${head[$k]}
coden=${code[$k]}
indexn=$k
fil=${page[$o]}
elapse=${clipsec[$o]}
      break
  fi 
if [ "${page[$o]}" != "$fil" ]
  then 
fil=${page[$o]}
elapse=${clipsec[$o]}
for n in `seq 0 $classno`;
do
if [[ "${smil[$n]}" == "$fil" ]];    
 then
headn=${head[$n]}
coden=${code[$n]}
indexn=$n   
break
fi 
done
 break
  fi 
o=$(($o-1))
done
;;

3)

i=0
for i in `seq 0 $pageno`;
do
if [[ "${page[$i]}" == "$fil" ]];    
    then
break
fi 
done
o=$(($i+1))

for k in `seq $o $pageno`;
do  

if [ "${page[$k]}" = "$fil" ] && [ "${clipsec[$k]}" -gt  "$dif" ]
  then 
headn=${head[$o]}
coden=${code[$o]}
indexn=$o
fil=${page[$k]}
elapse=${clipsec[$k]}
break
fi 
if [ "${page[$k]}" != "$fil" ]
  then 
fil=${page[$k]}
elapse=${clipsec[$k]}
for n in `seq 0 $classno`;
do
if [[ "${smil[$n]}" == "$fil" ]];    
 then
headn=${head[$n]}
coden=${code[$n]}
indexn=$n   
break
fi 
done
break
  fi 
done
;;
esac
#codeplus=$(($coden+1))
#codeminus=$(($coden-1))

navigate=0 
echo end of navigate 
echo $fil 
_mp3player $path"/"$fil $elapse $navigate $sleeptime $tit $exit 
else 
break 
fi
 done

}

####################################################################
_ncc()
{
 navigate=0
 string=$(cat $ncc ) 
sign1='<meta name="ncc:depth" content=' 
test1=$( cat $ncc | grep "$sign1")
 nothing="" 
if [[ $test1 = $nothing ]]

 then 
  depth=1
else 
depth=$(awk -v a="$test1"    'BEGIN{print substr(a,35,1)}')   

fi 
echo $depth
sign1='<meta name="dc:title" content='
test1=$( cat $ncc | grep "$sign1")
leng=$((${#test1}-37))
title=$(awk -v a="$test1" -v b="$leng"   'BEGIN{print substr(a,34,b)}')   
tit=$(echo $title|sed 's/ //g')
espeak $tit
inx=5
inx=$(awk -v a="$string" -v b="<body" 'BEGIN{print index(a,b)+1}')
strin=${string:$inx}
classno=$(echo  $strin| grep -o "<h"|wc  -l)
#echo $classno		
classno=$(($classno-1))
	
inx=3
for i in `seq 0 $classno`;
do 
strin=${strin:$inx}
inx=$(awk -v a="$strin" -v b="<h" 'BEGIN{print index(a,b)+2}')
head[$i]=$(awk -v a="$strin" -v b="$inx"    'BEGIN{print substr(a,b,1)}')
sub=$(awk -v a="$strin" -v b="$inx"    'BEGIN{print substr(a,b)}')
nam=$(awk -v a="$sub" -v  b="href="    'BEGIN{print index(a,b)+6}')
ext=$(awk -v a="$sub" -v  b=".smil" 'BEGIN{print index(a,b)}')
leng=$(($ext-$nam))
ssmil[$i]=$(awk -v a="$sub" -v b="$nam"  -v c="$leng" 'BEGIN{print substr(a,b,c)}')".smil"
str=$(cat $path"/"${ssmil[$i]})
inxx=$(awk -v a="$str" -v b="<audio src=" 'BEGIN{print index(a,b)+11}')
subb=${str:$inxx}
inxy=$(awk -v a="$subb" -v  b=".mp3"    'BEGIN{print index(a,b)+3}')
smil[$i]=$(awk -v a="$subb" -v b=1  -v c="$inxy" 'BEGIN{print substr(a,b,c)}')

code[$i]=0 
done

#_coding
_pre
_navigating 
}
########################################################################

_ncx(){
slash="/"
navigate=0
echo $ncx
	string=$(cat $ncx )	 
        strin=$( echo $string| sed -n "s/.*\(<navMap.*<\/navMap\).*/\1/p"   )
        pagearea=$( echo $string| sed -n "s/.*\(<pageList.*<\/pageList\).*/\1/p"   )
        if [ ${#pagearea} -eq 0 ]
              then
                           pagearea=$( echo $string| sed -n "s/.*\(<navList.*<\/navList\).*/\1/p"   )

        fi

	classno=$(echo  $strin| grep -o "class="|wc  -l)
               classno_=$(($classno-1))	
        pageno=$(echo  $pagearea| grep -o "class="|wc  -l)


        echo    $pagearea >page.txt
       ./page >pag.txt
        page=($(cat pag.txt|awk '{print $2}'))
        clip=($(cat pag.txt|awk '{print $1}')) 
           inx=5
	################################################################
	inx=$(awk -v a="$string" -v b="<docTitle>" 'BEGIN{print index(a,b)+5}')
	sub=$(awk -v a="$string" -v b="$inx"    'BEGIN{print substr(a,b)}')
	nam=$(awk -v a="$sub" -v  b="<text>"    'BEGIN{print index(a,b)+6}')
	ext=$(awk -v a="$sub" -v  b="</text>"   'BEGIN{print index(a,b)}')
	leng=$(($ext-$nam))
	title=$(awk -v a="$sub" -v b="$nam"  -v c="$leng" 'BEGIN{print substr(a,b,c)}')
	tit=$(echo $title|sed 's/ //g')
           espeak $tit
	###########################################################################
         sign1='<meta name="dtb:depth" content='
         sign2='name="dtb:depth"'
         test1=$( cat $ncx | grep "$sign1")
         test2=$( cat $ncx | grep "$sign2")
         if [ "$test1" = "$test2" ]
              then 
              depth=$(awk -v a="$test1"    'BEGIN{print substr(a,33,1)}')   
       else  
	inx=$(awk -v a="$string" -v b="dtb:depth" 'BEGIN{print index(a,b)-9}')
	depth=$(awk -v a="$string" -v b="$inx"    'BEGIN{print substr(a,b,1)}')
	fi
      echo $depth

_paging 
_heading $classno $strin

_pre 
#_coding
_navigating

}
#************************************
_daisy()
{
#amixer sset 'Analog' 1 
#amixer sset 'Analog Left AUXL' cap
#amixer sset 'Analog Right AUXR' cap
#amixer sset 'TX1' 'Analog'
#amixer sset 'TX1 Digital' 5 
#for rpi
#amixer cset numid=1 100%
#numid=3,iface=MIXER,name='PCM Playback Volume'
 # ; type=INTEGER,access=rw------,values=2,min=0,max=65536,step=1
  #: values=65536,65536
#amixer cset numid=2 on
#numid=4,iface=MIXER,name='PCM Playback Switch'
 # ; type=BOOLEAN,access=rw------,values=1
 # : values=on
#63.+ alsactl store


#echo $1
path=$newpath
sleeptime=0



ncx=$(find  $path  -type f -name "*.ncx")
ncc=$(find  $path  -type f -name "ncc.html")
if [ -n "$ncx"  ]
then
ncxfile=$(ls $ncx | xargs -n1 basename)
fullpath=$(echo $ncx|sed  's/'$ncxfile'.*//')
path=$fullpath
opf=$(find  $path -type f -name "*.opf")
  

         sign1='<meta name="dtb:totalTime" content='
         sign2='name="dtb:totalTime"'             
         test1=$( cat $opf | grep "$sign1")            
         test2=$( cat $opf | grep "$sign2")
          if [ "$test1" = "$test2" ]
              then
               
              totaltime=$(awk -v a="$test1"    'BEGIN{print substr(a,38,8)}')   
          else
               	sub=$(awk -v a="$test2"    'BEGIN{print substr(a,25)}')
                nam=$(awk -v a="$sub" -v  b='"' 'BEGIN{print index(a,b)}')
              totaltime=$(awk -v a="$sub" -v  b=1 -v c="$nam"  'BEGIN{print substr(a,b,c-1)}')   
          fi


fi
if [ -n "$ncc"  ]
then
fullpath=$(echo $ncc|sed  's/ncc.html.*//')
path=$fullpath

 sign1='<meta name="ncc:totalTime" content'
 test1=$( cat $ncc | grep "$sign1")      
 totaltime=$(awk -v a="$test1"    'BEGIN{print substr(a,39,8)}')   


fi
echo $totaltime
_time_calculator $totaltime
while true
do 
_key s
case $s in 
  ?) key=$s ;;
  *) key=??? ;;
esac

case $key in

6)
 sleeptime=900
  break;;
2)
 sleeptime=1800
  break
;;
4)
 sleeptime=2700
  break;;
8)
 sleeptime=3600
 break;;
5) 
sleeptime=$seconds


break;;
esac
done

	
echo $sleeptime

if [ -n "$ncx"  ]
then
     exit=0  
 echo $ncx
           _ncx $ncx $path  $sleeptime $seconds $exit			
           		 

fi
if [ -n "$ncc"  ]
then
exit=0
_ncc $ncc $path  $sleeptime $seconds $exit			

fi
rm *.mp3
}
########################################
_talking_player(){
          temp=0
	date1=$(date +"%s")
	lentgh=$(cat text.txt | wc -m )
	string=$(cat text.txt)
        silence=0  
	num=0
	volume=100
	speed=175
	pause=0	 
        braille=0
	su=0
	vu=0
        echo  ${string:$num}| espeak -a $volume  -s $speed &
          
	while [[  $num -le $lentgh ]]
	do

 read -n1 -t1 z 
case "$z" in

5)
	 if [ $pause -eq 0 ]
	then 
	 killall -v espeak
	  pause=1
	  date2=$(date +"%s")
	  diff=$(($date2-$date1))
            echo $diff
          date1=$(date +"%s")
          else 
	  date2=$(date +"%s")
	  silence=$(($date2-$date1))
  
 ndiff=$(($diff*15))
 num=$(($num+$ndiff))
   echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s")

	   pause=0
	fi;;
0)
	    killall -v espeak
 	   break;;
3) 
         date2=$(date +"%s")
	  diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
          su=$(($su-1))       
          su=$(($su*20))           
          speed=$(($speed+$su))    
echo $speed
           
          if   [ $speed -lt 80 ] 
          then
                speed=80
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;

9)
     date2=$(date +"%s")
	  diff=$(($date2-$date1))
 ndiff=$(($diff*15))
          num=$(($num+$ndiff))
          su=$(($su+1))                  
          speed=$(($su*20+$speed))    
          if   [$speed -gt 450] 
          then
                speed=450
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
7)
	date2=$(date +"%s")
	diff=$(($date2-$date1))
	 ndiff=$(($diff*15))
echo $ndiff
echo $num
        num=$(($num+$ndiff))

echo $num
        temp=$(($num+100))
	if [[ $temp  -le $lentgh ]]
        then 
	killall -v espeak
	 num=$(($num+100))
	    echo  ${string:$num} |espeak -a $volume  -s $speed &
         date1=$(date +"%s")
	fi;;
1)
	date2=$(date +"%s")
	diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	num=$(($num+$ndiff))
	if [ $num -ge 100 ] 
       	then 
	killall -v espeak
	 num=$(($num-100))
	    echo  ${string:$num} |espeak -a $volume  -s $speed &
         date1=$(date +"%s")
		
	fi;;
-)					
          date2=$(date +"%s")
          diff=$(($date2-$date1))
       ndiff=$(($diff*15))	  
     num=$(($num+$ndiff))
          vu=$(($vu-1))                  
          volume=$(($volume+$vu*20))    
          if   [$volume -lt 0] 
          then
                volume=0
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
+) 
         date2=$(date +"%s")
	  diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
           vu=$(($vu+1))                  
          volume=$(($volume+$vu*20))    
          if   [$volume -gt 200] 
          then
                volume=200
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
b)

if [ $braille -eq 0 ]
	then 
	 killall -v espeak
	  braille=1
	  date2=$(date +"%s")
	  diff=$(($date2-$date1))
          ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
     # killall -v brltty          
#brltty -bal     -xwd     
 echo  ${string:$num:100}|tr -d '\n' > str.txt
          ./pre
cat  out.txt|sed 's/\//\\/g'|sed  's/x0020/   /g' | sed  's/\\/ /g' >input.txt
    
       ./braille      
    date1=$(date +"%s")

else 
	  date2=$(date +"%s")
	  silence=$(($date2-$date1))
          num=$(($num+100))
      #    killall -v   brltty
       echo  ${string:$num} |espeak -a $volume  -s $speed &
       date1=$(date +"%s")
       braille=0
	fi;;
esac
done 
echo "end of loop"	
}

####################################################
	
_player(){
date1=$(date +"%s")
duration=$(mp3info -p %S ${line[$i]})
###############################3
y=2
volume=50; 
speed=1.0;
pause=0	 
interval=0
tpause=0
diff=0
while  [[ $duration -ge  $diff ]] 
do
date2=$(date +"%s")
diff=$(($date2-$date1+$interval-$tpause))
echo $duration
echo $diff
aoss mp3blaster ${line[$i]} -c mp3blast &&
 read -n1 -t1 y 
case "$y" in
5)
 if [ $pause -eq 0 ]
then 
  #alsaplayer  --pause  ${line[$i]}
  pause=1
  tpause=$(date +"%s")
  pause_diff=$(($tpause-$date1))
	
 else 
  rdate=$(date +"%s")
  tpause=$(($rdate-$tpause))
  echo $tpause
  #alsaplayer  --start --relative $pause_diff   ${line[$i]} 
					pause=0
fi;;
0)
killall -v mp3blaster
#  alsaplayer  --quit  ${line[$i]}
   break;;
3)
	   speed=$(echo $speed-0.1|bc);;
          #  alsaplayer --speed  $speed ${line[$i]} ;;
9)
	   speed=$(echo $speed+0.1|bc)  ;;
           # alsaplayer --speed  $speed ${line[$i]} ;;
7)
    interval=$(($interval+10));;
   #alsaplayer  --relative 10   ${line[$i]} ;;
				
1)
    interval=$(($interval-10));;
  #alsaplayer   --relative -10   ${line[$i]} ;;
-)
   volume=$((Svolume-10))
     amixer set Headset Playback Volume  $volume"%";;
  
  
+)
 volume=$((Svolume+10))
     amixer set Headset Playback Volume  $volume"%";;

esac


done
killall -v mp3blaster
#alsaplayer --quit  ${line[$i]}

}

##########################main########################
pmount /dev/sda1 /media/usbdrive
path="/media/usbdrive"
#path=$(pwd)
#path="/home/azi/Downloads/media"
line=($(ls $path))
no=${#line[@]}
T="`date +"%H %M"`"
D="`date +"%Y %m %d"`"
stay=1
while    [ $stay -eq 1 ]
do 
i=0
while [ $i  -lt $no ] || [ $i  -gt 0 ]
do

if [ $i  -eq $no ] 
 then
  i=0
fi

espeak ${line[$i]}
_key x
case $x in
 
  ?) key=$x ;;
  *) key=??? ;;
esac
 if [ $key = 5 ]
then
 stay=0
break
fi

if [ $key = 7 ]
then
 i=$(( $i + 1 ))
 fi
if [ $key = 1 ]
then
 i=$(( $i - 1 ))
 if [ $i  -lt 0 ] 
 then
  i=$(($no+$i))
fi
fi
if [ $key =  0 ]
then
  break
fi
 done 
   
if [  $stay        -eq 1 ]
then 
case "${line[$i]}" in
    *.mp3*) _player  $path"/"${line[$i]} ;;
    *.html*) html2text  -o text.txt ${line[$i]};espeak -f text.txt -w wave.wav;_player text.wav;;
    *.wav*) _player  ${line[$i]} ;;
    *.txt*) cp $path"/"${line[$i]} "text.txt" ;_talking_player text.txt;;
#espeak -f text.txt -w wave.wav,_player text.wav;;
    *.pdf*) 
cp $path"/"${line[$i]} "sample.pdf"
pdftohtml  sample.pdf   -xml -c
sign=$( cat sample.xml |grep -o "<b>"|wc -l)
if [ $sign -eq  0 ]
then  
pdftoppm sample.pdf text 
 convert text*.ppm text.png 
tesseract text.png text
_talking_player    text.txt
else 
 ./pdf.sh   sample.pdf
fi ;;

#espeak -f text.txt -w wave.wav;
#_player text.wav;;
    *.odt*) ./odt2txt ${line[$i]} > text.txt;espeak -f text.txt -w wave.wav;_player text.wav;;
    *.docx*)  cp ${line[$i]} "text.docx"; ./docx2txt.sh text.docx > text.txt;espeak -f text.txt -w wave.wav;_player text.wav;;
    *.doc)  cp ${line[$i]} "text.doc"; abiword --to=txt text.doc;espeak -f text.txt -w wave.wav;_player text.wav;;
    *.3gp*) cp ${line[$i]} "audio.3gp";ffmpeg -y -i 	 audio.3gp -ac 1 -acodec mp3 -ar 22050 -f wav audio.mp3;_player audio.mp3;;
    *)path="/media/usbdrive";newpath=$path"/"${line[$i]};_daisy   $newpath  ;;
esac
fi
done
pumount /dev/sda1
	



#FOR HINDI TTS:espeak -f text.txt -w wave.wav -v hi

