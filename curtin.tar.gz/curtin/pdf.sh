
#structure-pdf navigator/reades.
#key 1,7 for selection part
#key 0 start to play part
#key 5 quit complete
#key 3,9 speed
#key 2,6 navigate
#key +,- vol
#key 1,7 rew,ff
#key 5 resume,pause
#key 0 exit from player not selector
#key b  braille terminal
#Braille:100 char send to pre to translate/remove x0020 /send too terminal 
#Brailleterminal  1 nothing  2  left 3 right      4 nothing  5 stop   6 nothing

#ps aux|grep brl  (check brltty is running or not
#if yes :killall -v   brltty then brltty -bal -xwd

####################################
_all() {
        
        j=0
        eaten=0    
 inx=$(awk  'BEGIN{print index('$str','$re')}')
        while [ $inx -gt 0 ]	
            do
             sinx[$j]=inx  
              eaten=$((${sinx[$j]}+5))
               str = ${str:$eaten}
                 j=$(($j+1))
        inx=$(awk  'BEGIN{print index('$str','$re')}')
    done
echo $j
}

##################################################

_talking_player(){
nav=1
espeak ${title[$i]}

         temp=0
	date1=$(date +"%s")
	lentgh=$(cat text.txt | wc -m )
	string=$(cat text.txt)
        #string=${tex[$i]}
         #lentgh=${len[$i]}
        
     echo $string 
       silence=0  
	num=0
	volume=100
	speed=175
	pause=0	 
        braille=0
	su=0
	vu=0
        echo  ${string:$num}| espeak -a $volume  -s $speed &
          
	while [[  $num -le $lentgh ]]
	do

 read -n1 -t1 z 
case "$z" in

5)
	 if [ $pause -eq 0 ]
	then 
	 killall -v espeak
	  pause=1
	  date2=$(date +"%s")
	  diff=$(($date2-$date1))
            echo $diff
          date1=$(date +"%s")
          else 
	  date2=$(date +"%s")
	  silence=$(($date2-$date1))
  
 ndiff=$(($diff*15))
 num=$(($num+$ndiff))
   echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s")

	   pause=0
	fi;;
0)
nav=0	
    killall -v espeak
 	   break;;
3) 
         date2=$(date +"%s")
	  diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
          su=$(($su-1))       
          su=$(($su*20))           
          speed=$(($speed+$su))    
echo $speed
           
          if   [ $speed -lt 80 ] 
          then
                speed=80
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;

9)
     date2=$(date +"%s")
	  diff=$(($date2-$date1))
 ndiff=$(($diff*15))
          num=$(($num+$ndiff))
          su=$(($su+1))                  
          speed=$(($su*20+$speed))    
          if   [$speed -gt 450] 
          then
                speed=450
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
7)
	date2=$(date +"%s")
	diff=$(($date2-$date1))
	 ndiff=$(($diff*15))
echo $ndiff
echo $num
        num=$(($num+$ndiff))

echo $num
        temp=$(($num+100))
	if [[ $temp  -le $lentgh ]]
        then 
	killall -v espeak
	 num=$(($num+100))
	    echo  ${string:$num} |espeak -a $volume  -s $speed &
         date1=$(date +"%s")
	fi;;
1)
	date2=$(date +"%s")
	diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	num=$(($num+$ndiff))
	if [ $num -ge 100 ] 
       	then 
	killall -v espeak
	 num=$(($num-100))
	    echo  ${string:$num} |espeak -a $volume  -s $speed &
         date1=$(date +"%s")
		
	fi;;
-)					
          date2=$(date +"%s")
          diff=$(($date2-$date1))
       ndiff=$(($diff*15))	  
     num=$(($num+$ndiff))
          vu=$(($vu-1))                  
          volume=$(($volume+$vu*20))    
          if   [$volume -lt 0] 
          then
                volume=0
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
+) 
         date2=$(date +"%s")
	  diff=$(($date2-$date1))
       ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
           vu=$(($vu+1))                  
          volume=$(($volume+$vu*20))    
          if   [$volume -gt 200] 
          then
                volume=200
          fi  
           killall -v espeak
           echo  ${string:$num} |espeak -a $volume  -s $speed &
           date1=$(date +"%s");;
b)

if [ $braille -eq 0 ]
	then 
	 killall -v espeak
	  braille=1
	  date2=$(date +"%s")
	  diff=$(($date2-$date1))
          ndiff=$(($diff*15))
	  num=$(($num+$ndiff))
      ##brltty -bal         
 echo  ${string:$num:100} >str.txt
      ./pre
cat  out.txt|sed 's/\//\\/g'|sed  's/x0020/   /g' | sed  's/\\/ /g' >input.txt
    

./braille      
    date1=$(date +"%s")

else 
	  date2=$(date +"%s")
	  silence=$(($date2-$date1))
       num=$(($num+100))
         killall -v   brltty
       echo  ${string:$num} |espeak -a $volume  -s $speed &
       date1=$(date +"%s")
       braille=0
	fi;;
6)
         killall -v espeak
          nav=6
             break;;



2)
         killall -v espeak
          nav=2
  break;;

esac
done 
#if [ $nav -eq 0 ]
#then 
#nav=1
#fi
echo "end of loop"	

}


################################################
_key()
{
  local kp
  ESC=$'\e'
  _KEY=
  read -d '' -sn1 _KEY
  case $_KEY in
    "$ESC")
        while read -d '' -sn1 -t1 kp
        do
          _KEY=$_KEY$kp
          case $kp in
            [a-zA-NP-Z~]) break;;
          esac
        done
    ;;
  esac
  printf -v "${1:-_KEY}" "%s" "$_KEY"
}

###############################################
#cp $1 pdf.pdf
#pdftohtml pdf.pdf  -xml -c
cat sample.xml > pdf.txt
level1=$(grep -c  "<b>" pdf.txt)
string=$(cat pdf.txt)
level1=$(($level1-1))
./head >h.txt
cat h.txt|sed -e 's/[\t ]//g;/^$/d'>head.txt
title=($(awk 'BEGIN {FS="%"};{print $1}' head.txt))
addr=($(awk 'BEGIN {FS="%"};{print $2}' head.txt))
no=${#title[@]}
echo $no
nav=0
T="`date +"%H %M"`"
D="`date +"%Y %m %d"`"
#for i in `seq 1 $no`;
#$do
#done



i=0
exit=0
while [ $exit -eq 0 ]
do 
if [ $nav -eq 0 ]
then
while [ $i  -lt $no ] || [ $i  -gt 0 ]
do

if [ $i  -eq $no ] 
 then
  i=0
fi
echo i am there 
espeak ${title[$i]}
_key x
case $x in
 
  ?) key=$x ;;
  *) key=??? ;;
esac
if [ $key -eq 5 ]
then
exit=1
break
 fi

if [ $key -eq 7 ]
then
 i=$(( $i + 1 ))
 fi
if [ $key -eq 1 ]
then
 i=$(( $i - 1 ))
 if [ $i  -lt 0 ] 
 then
  i=$(($no+$i))
fi
fi
if [ $key -eq  0 ]
then
  break
fi
 done    
fi 


if [ $exit -eq 0 ]
then 

if [ $nav -eq 2 ]
then 
  i=$(($i-1))
fi 
if [ $nav -eq 6 ] || [ $nav -eq 1 ]
then 

i=$(($i+1))
fi

echo $i"IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII"
a=${addr[$i]}
j=$(($i+1))
b=${addr[$j]}
len=$(($b-$a))
text=${string:$a:$len}
echo $text>html.txt
html2text  -o  text.txt html.txt
cat text.txt
#lent[$i]=$(wc -m  text.txt|sed 's/text.txt//g')
#tex[$i]=$(cat text.txt) 

_talking_player 
fi
done









